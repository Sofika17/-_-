package com.example.demo_Ivanova;

public class AdminController {
}
