package com.example.demo_Ivanova;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@SpringBootApplication
@EnableWebSecurity
public class DemoIvanovaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoIvanovaApplication.class, args);
    }

    @Bean
    PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(); }

    @Bean
    UserDetailsService userDetailsService(PasswordEncoder pe) {
        return new InMemoryUserDetailsManager(
                User.withUsername("admin")
                        .password(pe.encode("admin"))
                        .roles("ADMIN")
                        .build());
    }

    @Bean
    SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(c -> c.ignoringRequestMatchers("/feedback", "/admin/**"))
                .authorizeHttpRequests(a -> a
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        .requestMatchers("/h2-console/**").permitAll()
                        .anyRequest().permitAll())
                .formLogin(f -> f.loginPage("/login").defaultSuccessUrl("/admin", true).permitAll())
                .logout(l -> l.logoutSuccessUrl("/"))
                .headers(h -> h.frameOptions(fo -> fo.disable())); // для H2 console
        return http.build();
    }
}