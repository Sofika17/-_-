package com.example.demo_Ivanova;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

class Entities {

    @Entity @Table(name = "users")
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class User {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Integer id;
        public String login;
        @Column(name="password_hash") public String passwordHash;
        public String email, role;
    }

    @Entity @Table(name = "categories")
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Category {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Integer id;
        public String name, slug;
    }

    @Entity @Table(name = "news")
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class News {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Integer id;
        public String title;
        @Column(columnDefinition = "TEXT") public String content;
        @Column(name="image_url") public String imageUrl;
        public String author;
        @Column(name="created_at") public LocalDateTime createdAt = LocalDateTime.now();
    }

    @Entity @Table(name = "services")
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Service {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Integer id;
        public String name;
        @Column(columnDefinition = "TEXT") public String description;
        public BigDecimal price;
        @Column(name="category_id") public Integer categoryId;
        @Column(name="image_url") public String imageUrl;
    }

    @Entity @Table(name = "feedback")
    @Data @NoArgsConstructor @AllArgsConstructor
    public static class Feedback {
        @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Integer id;
        public String name, email, phone;
        @Column(columnDefinition = "TEXT") public String message;
        public String status = "NEW";
        @Column(name="created_at") public LocalDateTime createdAt = LocalDateTime.now();
    }
}
