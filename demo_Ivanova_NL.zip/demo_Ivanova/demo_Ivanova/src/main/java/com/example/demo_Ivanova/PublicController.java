package com.example.demo_Ivanova;

import com.example.demo_Ivanova.Entities.*;
import com.example.demo_Ivanova.Repos.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
class PublicController {

    private final NewsRepo news;
    private final ServiceRepo services;
    private final CategoryRepo cats;
    private final FeedbackRepo feedback;

    PublicController(NewsRepo n, ServiceRepo s, CategoryRepo c, FeedbackRepo f) {
        this.news = n; this.services = s; this.cats = c; this.feedback = f;
    }

    @GetMapping("/")
    String index(Model m) {
        m.addAttribute("latestNews",
                news.findAll(PageRequest.of(0, 3, Sort.by("createdAt").descending())).getContent());
        return "index";
    }

    @GetMapping("/about") String about() { return "about"; }

    @GetMapping("/services")
    String services(@RequestParam(required = false) Integer category, Model m) {
        m.addAttribute("categories", cats.findAll());
        m.addAttribute("selected", category);
        m.addAttribute("services",
                category == null ? services.findAll() : services.findByCategoryId(category));
        return "services";
    }

    @GetMapping("/news")
    String newsList(@RequestParam(defaultValue = "0") int page, Model m) {
        m.addAttribute("newsPage",
                news.findAll(PageRequest.of(page, 3, Sort.by("createdAt").descending())));
        return "news";
    }

    @GetMapping("/news/{id}")
    String newsDetail(@PathVariable Integer id, Model m) {
        m.addAttribute("n", news.findById(id).orElseThrow());
        return "news-detail";
    }

    @GetMapping("/contacts")
    String contacts(Model m) { m.addAttribute("feedback", new Feedback()); return "contacts"; }

    @PostMapping("/feedback")
    String send(@ModelAttribute Feedback f, Model m) {
        f.setId(null);
        f.setStatus("NEW");
        feedback.save(f); // ← сохранение в БД
        m.addAttribute("success", "Заявка отправлена!");
        m.addAttribute("feedback", new Feedback());
        return "contacts";
    }

    @GetMapping("/search")
    String search(@RequestParam(required = false) String q, Model m) {
        if (q != null && !q.isBlank()) {
            m.addAttribute("newsList", news.findByTitleContainingIgnoreCase(q));
            m.addAttribute("serviceList", services.findByNameContainingIgnoreCase(q));
        }
        m.addAttribute("q", q);
        return "search";
    }

    @GetMapping("/login") String login() { return "login"; }
}