package com.example.demo_Ivanova;

import com.example.demo_Ivanova.Entities.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

interface Repos {
    interface UserRepo extends JpaRepository<User, Integer> {}
    interface CategoryRepo extends JpaRepository<Category, Integer> {}
    interface NewsRepo extends JpaRepository<News, Integer> {
        List<News> findByTitleContainingIgnoreCase(String q);
    }
    interface ServiceRepo extends JpaRepository<Service, Integer> {
        List<Service> findByCategoryId(Integer categoryId);
        List<Service> findByNameContainingIgnoreCase(String q);
    }
    interface FeedbackRepo extends JpaRepository<Feedback, Integer> {}
}