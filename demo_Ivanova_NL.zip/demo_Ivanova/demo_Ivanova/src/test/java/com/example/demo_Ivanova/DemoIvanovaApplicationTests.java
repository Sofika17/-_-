package com.example.demo_Ivanova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIvanovaApplicationTests {

	@Test
	void contextLoads() {
	}

}
